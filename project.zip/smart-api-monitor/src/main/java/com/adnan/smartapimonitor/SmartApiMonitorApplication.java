package com.adnan.smartapimonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartApiMonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartApiMonitorApplication.class, args);
	}

}
